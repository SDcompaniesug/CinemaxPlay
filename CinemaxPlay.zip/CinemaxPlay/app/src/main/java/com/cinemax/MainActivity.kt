package com.cinemax

import android.os.Bundle
import android.os.Build
import android.Manifest
import android.content.pm.PackageManager
import android.content.pm.ActivityInfo
import android.app.NotificationChannel
import android.app.NotificationManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import android.os.Handler
import android.os.Looper
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.view.Gravity
import android.util.LruCache
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.widget.Button
import android.widget.CompoundButton
import android.widget.ProgressBar
import android.widget.SeekBar
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import com.google.android.material.bottomsheet.BottomSheetDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.textfield.TextInputEditText
import java.util.Locale
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

private const val PREFS = "cinemax_play_preferences"

/** Lightweight asynchronous image loader; avoids requiring an external image-loading library. */
private object RemoteImages {
    private val executor = Executors.newFixedThreadPool(4)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val maxCacheSize = (Runtime.getRuntime().maxMemory() / 8L).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
    private val cache = object : LruCache<String, Bitmap>(maxCacheSize) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun load(view: ImageView, imageUrl: String, placeholder: Int? = null) {
        view.tag = imageUrl
        view.scaleType = ImageView.ScaleType.CENTER_CROP
        if (placeholder != null) view.setImageResource(placeholder) else view.setImageDrawable(null)
        val cached = cache.get(imageUrl)
        if (cached != null) {
            view.setImageBitmap(cached)
            return
        }
        executor.execute {
            val bitmap = try {
                val connection = (URL(imageUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 10000
                    readTimeout = 15000
                    instanceFollowRedirects = true
                }
                try { connection.inputStream.use { BitmapFactory.decodeStream(it) } } finally { connection.disconnect() }
            } catch (_: Exception) { null }
            if (bitmap != null) cache.put(imageUrl, bitmap)
            mainHandler.post {
                if (view.tag == imageUrl) {
                    if (bitmap != null) view.setImageBitmap(bitmap)
                    else if (placeholder != null) view.setImageResource(placeholder)
                }
            }
        }
    }
}

private data class CastMember(val name: String, val image: String)
private data class TitleItem(
    val id: String, val title: String, val year: Int, val type: String, val genre: String,
    val rating: Double, val duration: String, val image: String, val description: String,
    val cast: List<CastMember>, val popular: Int, val seasons: Int = 0
)
private data class NoticeItem(val title: String, val message: String)
private data class EpisodeItem(val season: Int, val number: Int, val title: String, val description: String, val duration: String, val image: String)

private object Catalog {
    private const val last = "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?auto=format&fit=crop&w=1200&q=85"
    private const val space = "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=700&q=80"
    private const val mountain = "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=700&q=80"
    private const val city = "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=700&q=80"
    private const val ocean = "https://images.unsplash.com/photo-1518837695005-2083093ee35b?auto=format&fit=crop&w=700&q=80"
    private const val forest = "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=700&q=80"
    private const val desert = "https://images.unsplash.com/photo-1509316785289-025f5b846b35?auto=format&fit=crop&w=700&q=80"
    private const val sea = "https://images.unsplash.com/photo-1500375592092-40eb2168fd21?auto=format&fit=crop&w=700&q=80"
    private const val snow = "https://images.unsplash.com/photo-1517299321609-52687d1bc55a?auto=format&fit=crop&w=700&q=80"
    private const val road = "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=700&q=80"
    private const val city2 = "https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=700&q=80"
    private const val water = "https://images.unsplash.com/photo-1473116763249-2faaef81ccda?auto=format&fit=crop&w=700&q=80"

    val titles = listOf(
        TitleItem("horizon", "The Last Horizon", 2025, "movie", "Sci-Fi", 8.7, "2h 08m", last,
            "When a mysterious signal arrives from the edge of the solar system, a fearless crew embarks on a journey that will change humanity forever. Beyond the stars, they discover a truth no one was prepared to face.", listOf(CastMember("Maya Chen", city), CastMember("Daniel Brooks", mountain), CastMember("Elena Rivers", sea), CastMember("James Carter", city)), 100),
        TitleItem("silent", "Silent Echoes", 2025, "movie", "Thriller", 8.4, "1h 56m", city,
            "A missing-person investigator returns to her hometown and uncovers a chain of secrets that should have stayed buried. Every clue brings her closer to the truth—and further into danger.", listOf(CastMember("Anna Reed", forest), CastMember("Marcus Hill", city2), CastMember("Leo Grant", road)), 95),
        TitleItem("wild", "Into the Wild", 2024, "movie", "Adventure", 8.1, "2h 02m", mountain,
            "Lost deep in a vast wilderness, two strangers must overcome the elements and their own pasts to find a way home. Their survival depends on learning to trust one another.", listOf(CastMember("Oliver Stone", mountain), CastMember("Nina West", sea), CastMember("Aaron Cole", forest)), 92),
        TitleItem("deep", "Deep Blue", 2025, "movie", "Action", 7.9, "1h 49m", ocean,
            "A research expedition discovers an impossible signal beneath the ocean floor. With time running out, the crew must face the unknown in the deepest place on Earth.", listOf(CastMember("Sofia Lane", sea), CastMember("Ethan Miles", city), CastMember("Grace Kim", water)), 88),
        TitleItem("shadow", "Shadow Protocol", 2024, "movie", "Action", 8.3, "2h 11m", desert,
            "An intelligence officer is framed for a global conspiracy and forced to operate outside the system. One mission, a hidden network, and a race against the clock.", listOf(CastMember("Noah Blake", road), CastMember("Mia Ford", city2), CastMember("Alex Quinn", city)), 86),
        TitleItem("orbit", "Beyond Orbit", 2025, "movie", "Sci-Fi", 8.6, "2h 01m", space,
            "The first mission to a distant moon finds signs of something extraordinary. As the crew investigates, the boundary between discovery and survival begins to disappear.", listOf(CastMember("Lena Frost", space), CastMember("David North", snow), CastMember("Iris Bell", sea)), 84),
        TitleItem("frozen", "Frozen Kingdom", 2024, "movie", "Fantasy", 7.8, "1h 58m", snow,
            "An exiled heir journeys across a frozen realm to reclaim a lost throne and end a winter that has lasted for generations.", listOf(CastMember("Eva Snow", snow), CastMember("Theo King", mountain), CastMember("Ruth Vale", forest)), 80),
        TitleItem("after", "After the Storm", 2023, "movie", "Drama", 8.0, "1h 52m", water,
            "A coastal community rebuilds after a devastating storm, finding courage and unexpected connection in the process.", listOf(CastMember("Clara Moore", water), CastMember("Ben Ellis", city), CastMember("Tara Wells", sea)), 77),
        TitleItem("neon", "Neon District", 2025, "series", "Crime", 8.8, "2 seasons", city2,
            "In a city that never sleeps, a determined detective follows a trail of corruption from the streets to the highest levels of power.", listOf(CastMember("Rafael Cruz", city2), CastMember("Leah Park", city), CastMember("Sam Jordan", road)), 99, 2),
        TitleItem("north", "Northbound", 2024, "series", "Drama", 8.5, "3 seasons", snow,
            "A small-town doctor returns to a remote northern community and finds that healing old wounds may be harder than saving lives.", listOf(CastMember("Emma Lake", snow), CastMember("Finn Woods", mountain), CastMember("Grace Hill", forest)), 93, 3),
        TitleItem("orbitals", "Orbital Station", 2025, "series", "Sci-Fi", 8.9, "1 season", space,
            "Life aboard a distant orbital station changes forever after a routine mission discovers an anomaly beyond the known universe.", listOf(CastMember("Nora Sky", space), CastMember("Peter Wells", city), CastMember("Jules Hart", sea)), 90, 1),
        TitleItem("kingdom", "The Hidden Kingdom", 2023, "series", "Fantasy", 8.2, "2 seasons", forest,
            "A young mapmaker discovers a forgotten kingdom and becomes the unlikely key to stopping an ancient conflict from returning.", listOf(CastMember("Lily Green", forest), CastMember("Arthur Vale", mountain), CastMember("Mira Dawn", water)), 85, 2),
        TitleItem("coast", "Coastline", 2024, "series", "Drama", 7.9, "2 seasons", sea,
            "Three families with intertwined histories navigate love, ambition and the secrets of a changing seaside town.", listOf(CastMember("Olivia Shore", sea), CastMember("Jack Reed", water), CastMember("Mason Grey", city)), 78, 2),
        TitleItem("velocity", "Velocity", 2025, "series", "Action", 8.1, "1 season", road,
            "A former racing champion joins an elite rescue unit where every second matters and every decision has consequences.", listOf(CastMember("Kai Brooks", road), CastMember("Maya Cole", city2), CastMember("Leo West", desert)), 83, 1)
    )
    fun byId(id: String) = titles.firstOrNull { it.id == id } ?: titles.first()
}

class MainActivity : AppCompatActivity() {
    private lateinit var contentFrame: FrameLayout
    private lateinit var bottomNav: BottomNavigationView
    private lateinit var globalSearch: TextInputEditText
    private var currentScreen = "home"
    private var previousScreen = "home"
    private var currentTitle = Catalog.titles.first()
    private var currentFilter = "All"
    private var expandedDescription = false
    private var updatingNavigation = false
    private var stoppedAtMillis = 0L
    private var splashOverlay: View? = null
    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }
    private val savedIds get() = prefs.getStringSet("saved_ids", emptySet())?.toMutableSet() ?: mutableSetOf()
    private val downloadedIds get() = prefs.getStringSet("downloaded_ids", emptySet())?.toMutableSet() ?: mutableSetOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.statusBarColor = getColor(R.color.cm_bg)
        window.navigationBarColor = getColor(R.color.cm_bg)
        contentFrame = findViewById(R.id.contentFrame)
        bottomNav = findViewById(R.id.bottomNav)
        globalSearch = findViewById(R.id.globalSearch)
        findViewById<View>(R.id.profileButton).setOnClickListener { showScreen("profile") }
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 4102)
        }
        updateNotificationDot()
        findViewById<View>(R.id.notificationsButton).setOnClickListener {
            prefs.edit().putBoolean("has_unread_notifications", false).apply()
            updateNotificationDot()
            showScreen("notifications")
        }
        bottomNav.setOnItemSelectedListener { item ->
            if (!updatingNavigation) {
                when (item.itemId) {
                    R.id.navHome -> showScreen("home")
                    R.id.navMovies -> showScreen("movies")
                    R.id.navSeries -> showScreen("series")
                    R.id.navList -> showScreen("list")
                    R.id.navProfile -> showScreen("profile")
                }
            }
            true
        }
        findViewById<View>(R.id.searchBox).setOnClickListener { showScreen("search") }
        globalSearch.setOnClickListener { showScreen("search") }
        globalSearch.setOnEditorActionListener { _, _, _ ->
            showScreen("search", globalSearch.text?.toString().orEmpty()); true
        }
        globalSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (s != null && s.length >= 2 && currentScreen == "search") bindCatalog("search", s.toString())
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        showScreen("home")
        // Show the branded splash on every fresh app launch for five seconds.
        showReturnSplash(5000L)
    }

    override fun onStop() {
        stoppedAtMillis = System.currentTimeMillis()
        super.onStop()
    }

    override fun onStart() {
        super.onStart()
        updateNotificationDot()
        if (stoppedAtMillis > 0L && System.currentTimeMillis() - stoppedAtMillis >= 60_000L) {
            showReturnSplash()
        }
        stoppedAtMillis = 0L
    }

    private fun showReturnSplash(durationMillis: Long = 5000L) {
        val host = findViewById<FrameLayout>(android.R.id.content)
        val overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(getColor(R.color.cm_bg))
            isClickable = true
            isFocusable = true
        }
        val icon = ImageView(this).apply {
            setImageResource(R.drawable.ic_cinemax_play)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Cinemax Play"
        }
        overlay.addView(icon, LinearLayout.LayoutParams(dp(54), dp(54)).apply { bottomMargin = dp(22) })
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            indeterminateTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.cm_accent))
            progressTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.cm_accent))
        }
        overlay.addView(progress, LinearLayout.LayoutParams(dp(104), dp(3)))
        host.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        splashOverlay = overlay
        Handler(Looper.getMainLooper()).postDelayed({
            (splashOverlay?.parent as? ViewGroup)?.removeView(splashOverlay)
            splashOverlay = null
        }, durationMillis)
    }

    private fun updateNotificationDot() {
        findViewById<View>(R.id.notificationDot)?.visibility =
            if (prefs.getBoolean("has_unread_notifications", false)) View.VISIBLE else View.GONE
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("cinemax_updates", "Cinemax Play updates", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Download and content update notifications"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun postLocalNotification(title: String, message: String) {
        prefs.edit().putBoolean("has_unread_notifications", true).apply()
        updateNotificationDot()
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        if (!prefs.getBoolean("all_notifications", true)) return
        val notification = NotificationCompat.Builder(this, "cinemax_updates")
            .setSmallIcon(R.drawable.ic_notifications)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(this).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
    }

    private fun showScreen(screen: String, argument: String = "") {
        currentScreen = screen
        contentFrame.removeAllViews()
        findViewById<View>(R.id.topBar).visibility = if (screen == "home") View.VISIBLE else View.GONE
        findViewById<View>(R.id.profileButton).visibility = if (screen == "home") View.VISIBLE else View.GONE
        findViewById<View>(R.id.notificationsButton).visibility = if (screen == "home") View.VISIBLE else View.GONE
        bottomNav.visibility = if (screen == "detail" || screen == "login") View.GONE else View.VISIBLE
        updateNavigationColors()
        when (screen) {
            "home" -> showHome()
            "movies", "series", "search" -> showCatalog(screen, argument)
            "detail" -> showDetail(argument)
            "profile" -> showProfile()
            "list" -> showMyList()
            "downloads" -> { startActivity(Intent(this, com.cinemax.download.DownloadActivity::class.java)); showProfile() }
            "history" -> showHistory()
            "preferences" -> showPreferences()
            "about" -> showLegal("About Cinemax Play", "Cinemax Play is your personal destination for discovering movies and series. Version 1.0.0\n\nBrowse titles, build your watch list, and manage your download queue. Streaming and offline playback require a configured media provider.")
            "terms" -> showLegal("Terms & Conditions", "Use Cinemax Play responsibly and only with content you are authorized to access. Availability, playback, and download features depend on connected content providers. These terms may be updated as the app evolves.")
            "privacy" -> showLegal("Privacy Policy", "Your local preferences, watch list, and download queue are stored on this device. This demo app does not connect to an account service. Content images may be loaded from remote image hosts. Clear cache removes temporary app cache files.")
            "notifications" -> showNotifications()
            "login" -> showSimple("Sign in", "Account authentication is not connected yet. Add your authentication provider to enable secure sign-in.", emptyList()) {}
            else -> showHome()
        }
    }

    private fun updateNavigationColors() {
        val selected = when (currentScreen) {
            "movies" -> R.id.navMovies
            "series" -> R.id.navSeries
            "list" -> R.id.navList
            "profile" -> R.id.navProfile
            else -> R.id.navHome
        }
        if (bottomNav.selectedItemId != selected) {
            updatingNavigation = true
            bottomNav.selectedItemId = selected
            updatingNavigation = false
        }
    }

    private fun showHome() {
        val root = layoutInflater.inflate(R.layout.view_home, contentFrame, false)
        contentFrame.addView(root)
        val featuredItems = listOf(Catalog.byId("horizon"), Catalog.byId("neon"), Catalog.byId("wild"), Catalog.byId("orbit"))
        val dots = root.findViewById<LinearLayout>(R.id.heroDots)
        var featuredIndex = 0
        fun renderFeatured(index: Int) {
            featuredIndex = index % featuredItems.size
            val featured = featuredItems[featuredIndex]
            RemoteImages.load(root.findViewById(R.id.heroImage), featured.image)
            root.findViewById<TextView>(R.id.heroTitle).text = featured.title
            root.findViewById<TextView>(R.id.heroRating).text = String.format(Locale.US, "%.1f", featured.rating)
            root.findViewById<TextView>(R.id.heroMeta).text = "${featured.genre} · ${if (featured.type == "series") "Series" else "Movie"} · ${featured.year} · ${featured.duration}"
            root.findViewById<MaterialButton>(R.id.heroWatch).setOnClickListener { showDetail(featured.id) }
            root.findViewById<MaterialButton>(R.id.heroDetails).setOnClickListener { showDetail(featured.id) }
            for (i in 0 until dots.childCount) {
                val dot = dots.getChildAt(i)
                val active = i == featuredIndex
                dot.layoutParams = LinearLayout.LayoutParams(if (active) dp(20) else dp(6), dp(6)).apply { marginStart = dp(3); marginEnd = dp(3) }
                dot.background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(if (active) getColor(R.color.cm_accent) else 0x99FFFFFF.toInt()) }
            }
        }
        dots.removeAllViews()
        repeat(featuredItems.size) { i ->
            val dot = View(this).apply { isClickable = true; setOnClickListener { renderFeatured(i) } }
            dots.addView(dot, LinearLayout.LayoutParams(dp(6), dp(6)).apply { marginStart = dp(3); marginEnd = dp(3) })
        }
        renderFeatured(0)
        val heroContainer = root.findViewById<View>(R.id.heroContainer)
        var swipeStartX = 0f
        heroContainer.setOnTouchListener { _, event ->
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN -> { swipeStartX = event.x; true }
                android.view.MotionEvent.ACTION_UP -> {
                    val delta = event.x - swipeStartX
                    if (kotlin.math.abs(delta) > dp(48)) {
                        renderFeatured(if (delta < 0) (featuredIndex + 1) % featuredItems.size else (featuredIndex - 1 + featuredItems.size) % featuredItems.size)
                        true
                    } else false
                }
                else -> true
            }
        }
        val sliderHandler = Handler(Looper.getMainLooper())
        val sliderTask = object : Runnable { override fun run() { if (root.isAttachedToWindow && currentScreen == "home") { renderFeatured((featuredIndex + 1) % featuredItems.size); sliderHandler.postDelayed(this, 5000) } } }
        sliderHandler.postDelayed(sliderTask, 5000)
        bindSection(root.findViewById(R.id.trendingSection), "Trending now", "Explore all", Catalog.titles.sortedByDescending { it.popular }.take(8)) { showScreen("movies") }
        bindSection(root.findViewById(R.id.popularSection), "Popular movies", "View all", Catalog.titles.filter { it.type == "movie" }.sortedByDescending { it.popular }) { showScreen("movies") }
        bindSection(root.findViewById(R.id.seriesSection), "Top series", "View all", Catalog.titles.filter { it.type == "series" }.sortedByDescending { it.rating }) { showScreen("series") }
        bindSection(root.findViewById(R.id.actionSection), "Action & adventure", "View all", Catalog.titles.filter { it.genre == "Action" || it.genre == "Adventure" }) { showCatalog("search", "Action") }
        bindSection(root.findViewById(R.id.recommendedSection), "Recommended for you", "Explore", Catalog.titles.sortedByDescending { it.rating }.take(8)) { showScreen("movies") }
        val anim = AlphaAnimation(0.82f, 1f).apply { duration = 520; fillAfter = true }
        root.startAnimation(anim)
    }

    private fun bindSection(section: View, title: String, action: String, items: List<TitleItem>, actionClick: () -> Unit) {
        section.findViewById<TextView>(R.id.sectionTitle).text = title
        section.findViewById<TextView>(R.id.sectionAction).text = action
        section.findViewById<TextView>(R.id.sectionAction).setOnClickListener { actionClick() }
        val recycler = section.findViewById<RecyclerView>(R.id.sectionRecycler)
        recycler.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        recycler.adapter = MovieAdapter(items, false) { showDetail(it.id) }
    }

    private fun showCatalog(screen: String, query: String = "") {
        if (screen != "search") currentFilter = "All"
        val root = layoutInflater.inflate(R.layout.view_catalog, contentFrame, false)
        contentFrame.addView(root)
        root.findViewById<TextView>(R.id.catalogTitle).text = when (screen) { "movies" -> "Explore movies"; "series" -> "Explore series"; else -> "Search" }
        root.findViewById<View>(R.id.catalogBack).setOnClickListener { showScreen("home") }
        val searchBox = root.findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.catalogSearchBox)
        val searchInput = root.findViewById<TextInputEditText>(R.id.catalogSearch)
        searchBox.visibility = if (screen == "search") View.VISIBLE else View.GONE
        if (screen == "search") {
            searchInput.setText(query)
            searchInput.setSelection(searchInput.text?.length ?: 0)
            searchInput.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    currentFilter = "All"
                    bindCatalog("search", s?.toString().orEmpty(), root)
                }
                override fun afterTextChanged(s: Editable?) = Unit
            })
        }
        val filterLayout = root.findViewById<LinearLayout>(R.id.catalogFilters)
        filterLayout.visibility = if (screen == "search") View.GONE else View.VISIBLE
        val filters = listOf("All", "Action", "Adventure", "Sci-Fi", "Thriller", "Drama", "Fantasy", "Crime")
        filterLayout.removeAllViews()
        filters.forEach { filter ->
            filterLayout.addView(makePill(filter, filter == currentFilter) {
                currentFilter = filter
                for (i in 0 until filterLayout.childCount) {
                    val pill = filterLayout.getChildAt(i) as TextView
                    stylePill(pill, pill.text.toString() == filter)
                }
                bindCatalog(screen, query, root)
            })
        }
        if (screen == "search" && query.isNotBlank()) currentFilter = "All"
        bindCatalog(screen, query, root)
    }

    private fun bindCatalog(screen: String, query: String, root: View = contentFrame.getChildAt(0)) {
        val recycler = root.findViewById<RecyclerView>(R.id.catalogRecycler) ?: return
        var items = when (screen) {
            "movies" -> Catalog.titles.filter { it.type == "movie" }
            "series" -> Catalog.titles.filter { it.type == "series" }
            else -> Catalog.titles
        }
        if (currentFilter != "All") items = items.filter { it.genre.equals(currentFilter, true) }
        if (query.isNotBlank()) items = items.filter { it.title.contains(query, true) || it.genre.contains(query, true) || it.year.toString().contains(query) }
        root.findViewById<TextView>(R.id.catalogCount).visibility = View.GONE
        recycler.layoutManager = GridLayoutManager(this, 3)
        recycler.adapter = MovieAdapter(items, true) { showDetail(it.id) }
    }

    private fun stylePill(pill: TextView, selected: Boolean) {
        pill.setBackgroundResource(if (selected) R.drawable.bg_pill_selected else R.drawable.bg_pill)
        pill.setTextColor(if (selected) getColor(R.color.cm_text) else Color.parseColor("#D4D9E3"))
    }

    private fun makePill(label: String, selected: Boolean, onClick: () -> Unit): TextView {
        val d = resources.displayMetrics.density
        return TextView(this).apply {
            text = label
            textSize = 13f
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (36 * d).toInt()).apply { marginEnd = (8 * d).toInt() }
            stylePill(this, selected)
            setPadding((16 * d).toInt(), 0, (16 * d).toInt(), 0)
            setOnClickListener { onClick() }
        }
    }

    private fun showMyList() {
        val root = layoutInflater.inflate(R.layout.view_mylist, contentFrame, false)
        contentFrame.addView(root)
        val allSaved = Catalog.titles.filter { savedIds.contains(it.id) }
        root.findViewById<View>(R.id.listBack).setOnClickListener { showScreen("home") }
        root.findViewById<TextView>(R.id.listSubtitle).visibility = View.GONE
        val recycler = root.findViewById<RecyclerView>(R.id.listRecycler)
        recycler.layoutManager = GridLayoutManager(this, 3)
        var selectedFilter = "All"
        fun applyListFilter(filter: String) {
            selectedFilter = filter
            val filtered = when (filter) { "Movies" -> allSaved.filter { it.type == "movie" }; "Series" -> allSaved.filter { it.type == "series" }; else -> allSaved }
            recycler.adapter = MovieAdapter(filtered, true) { showDetail(it.id) }
            root.findViewById<TextView>(R.id.listEmpty).visibility = if (filtered.isEmpty()) View.VISIBLE else View.GONE
            root.findViewById<TextView>(R.id.listEmpty).text = when (filter) { "Movies" -> "No movies in your list yet"; "Series" -> "No series in your list yet"; else -> "Nothing saved yet" }
        }
        root.findViewById<View>(R.id.listFilterButton).setOnClickListener { anchor ->
            val popup = android.widget.PopupMenu(this, anchor)
            listOf("All", "Movies", "Series").forEach { label ->
                popup.menu.add(label).apply { isCheckable = true; isChecked = label == selectedFilter }
            }
            popup.setOnMenuItemClickListener { item ->
                applyListFilter(item.title.toString())
                true
            }
            popup.show()
        }
        applyListFilter("All")
    }

    private fun episodesFor(season: Int): List<EpisodeItem> {
        val images = Catalog.titles.map { it.image }.distinct()
        val names = listOf("The Beginning", "First Contact")
        return (1..6).map { n ->
            EpisodeItem(season, n, names.getOrNull(n - 1) ?: "Episode $n",
                "A new chapter unfolds as the team faces unexpected challenges.", "42 min", images[(season * 3 + n) % images.size])
        }
    }

    private fun showDetail(id: String) {
        if (currentScreen != "detail") previousScreen = currentScreen
        currentTitle = Catalog.byId(id)
        val recent = prefs.getStringSet("history_ids", emptySet())?.toMutableList() ?: mutableListOf()
        recent.remove(id); recent.add(0, id)
        prefs.edit().putStringSet("history_ids", recent.take(30).toSet()).apply()
        expandedDescription = false
        currentScreen = "detail"
        updateNavigationColors()
        bottomNav.visibility = View.GONE
        findViewById<View>(R.id.topBar).visibility = View.GONE
        contentFrame.removeAllViews()
        val root = layoutInflater.inflate(R.layout.view_detail, contentFrame, false)
        contentFrame.addView(root)
        val item = currentTitle
        RemoteImages.load(root.findViewById(R.id.detailBanner), item.image)
        root.findViewById<TextView>(R.id.detailTitle).text = item.title
        root.findViewById<TextView>(R.id.detailEyebrow).text = if (item.type == "series") "ORIGINAL SERIES" else item.genre.uppercase(Locale.getDefault())
        root.findViewById<TextView>(R.id.detailMeta).text = "${String.format(Locale.US, "%.1f", item.rating)}   ·   ${item.genre}   ·   ${item.year}   ·   ${item.duration}"
        root.findViewById<View>(R.id.detailBack).setOnClickListener { showScreen(previousScreen) }
        root.findViewById<View>(R.id.detailShare).setOnClickListener {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, item.title)
                putExtra(Intent.EXTRA_TEXT, "Check out ${item.title} on Cinemax Play!")
            }
            startActivity(Intent.createChooser(shareIntent, "Share ${item.title}"))
        }
        root.findViewById<MaterialButton>(R.id.detailWatch).setOnClickListener {
            openPlayer(item)
        }
        val saveButton = root.findViewById<MaterialButton>(R.id.detailSave)
        fun updateSaveLabel() {
            val isSaved = savedIds.contains(item.id)
            saveButton.text = if (isSaved) "In list" else "My List"
            saveButton.setIconResource(if (isSaved) R.drawable.ic_check else R.drawable.ic_add)
        }
        updateSaveLabel()
        saveButton.setOnClickListener {
            val ids = savedIds
            if (ids.contains(item.id)) ids.remove(item.id) else ids.add(item.id)
            prefs.edit().putStringSet("saved_ids", ids).apply()
            updateSaveLabel()
            Toast.makeText(this, if (ids.contains(item.id)) "Added to My List" else "Removed from My List", Toast.LENGTH_SHORT).show()
        }
        root.findViewById<MaterialButton>(R.id.detailDownload).visibility = if (item.type == "movie") View.VISIBLE else View.GONE
        root.findViewById<MaterialButton>(R.id.detailDownload).setOnClickListener {
            val ids = downloadedIds; ids.add(item.id); prefs.edit().putStringSet("downloaded_ids", ids).putString("download_state_${item.id}", "Queued").apply()
            postLocalNotification("Download queued", "${item.title} was added to your downloads.")
            Toast.makeText(this, "Added to download queue. A media download URL is required for offline playback.", Toast.LENGTH_LONG).show()
        }
        val description = root.findViewById<TextView>(R.id.detailDescription)
        val more = root.findViewById<TextView>(R.id.detailMore)
        description.text = item.description
        more.setOnClickListener {
            expandedDescription = !expandedDescription
            description.maxLines = if (expandedDescription) Int.MAX_VALUE else 3
            more.text = if (expandedDescription) "View less" else "View more"
        }
        val episodesSection = root.findViewById<View>(R.id.episodesSection)
        if (item.type == "series") {
            episodesSection.visibility = View.VISIBLE
            val episodeRecycler = root.findViewById<RecyclerView>(R.id.episodesRecycler)
            episodeRecycler.layoutManager = LinearLayoutManager(this).apply { isItemPrefetchEnabled = false }
            episodeRecycler.isNestedScrollingEnabled = false
            episodeRecycler.setHasFixedSize(false)
            val seasonLayout = root.findViewById<LinearLayout>(R.id.seasonPills)
            fun showSeason(season: Int) {
                episodeRecycler.adapter = EpisodeAdapter(episodesFor(season), { ep ->
                    Toast.makeText(this, "${item.title} S${ep.season}:E${ep.number} · playback source not configured yet.", Toast.LENGTH_SHORT).show()
                }, { _ ->
                    val ids = downloadedIds; ids.add(item.id); prefs.edit().putStringSet("downloaded_ids", ids).putString("download_state_${item.id}", "Queued").apply()
                    postLocalNotification("Download queued", "${item.title} was added to your downloads.")
                    Toast.makeText(this, "Added to download queue. A media download URL is required for offline playback.", Toast.LENGTH_LONG).show()
                })
            }
            seasonLayout.removeAllViews()
            for (season in 1..item.seasons.coerceAtLeast(1)) {
                seasonLayout.addView(makePill("Season $season", season == 1) {
                    for (i in 0 until seasonLayout.childCount) stylePill(seasonLayout.getChildAt(i) as TextView, i == season - 1)
                    showSeason(season)
                })
            }
            showSeason(1)
        } else episodesSection.visibility = View.GONE
        val castRecycler = root.findViewById<RecyclerView>(R.id.castRecycler)
        castRecycler.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        castRecycler.adapter = CastAdapter(item.cast)
        val related = Catalog.titles.filter { it.id != item.id && (it.genre == item.genre || it.type == item.type) }.take(8)
        val relatedRecycler = root.findViewById<RecyclerView>(R.id.relatedRecycler)
        relatedRecycler.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        relatedRecycler.adapter = MovieAdapter(related, false) { showDetail(it.id) }
    }

    private fun showProfile() {
        val root = layoutInflater.inflate(R.layout.view_profile, contentFrame, false)
        contentFrame.addView(root)
        val name = prefs.getString("profile_name", "Guest viewer") ?: "Guest viewer"
        val email = prefs.getString("profile_email", "Sign in to personalize your experience") ?: "Sign in to personalize your experience"
        root.findViewById<TextView>(R.id.profileName).text = name
        root.findViewById<TextView>(R.id.profileEmail).text = email
        root.findViewById<TextView>(R.id.profileAvatar).text = name.firstOrNull()?.uppercaseChar()?.toString() ?: "G"
        root.findViewById<MaterialButton>(R.id.profileSignIn).setOnClickListener { showScreen("login") }
        root.findViewById<View>(R.id.profileMyList).setOnClickListener { showScreen("list") }
        root.findViewById<View>(R.id.profileDownloads).setOnClickListener { startActivity(Intent(this, com.cinemax.download.DownloadActivity::class.java)) }
        root.findViewById<View>(R.id.profileHistory).setOnClickListener { showScreen("history") }
        val container = (root as ViewGroup).getChildAt(0) as LinearLayout
        // Group preferences and app information into compact, consistent cards.
        addProfileSection(container, "PREFERENCES")
        val preferencesGroup = addProfileGroup(container)
        val preferenceOptions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.VISIBLE; setPadding(dp(8), 0, dp(8), dp(8)) }
        fun addInlineToggle(title: String, subtitle: String, key: String, default: Boolean) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(12), dp(10), dp(12)) }
            val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
            labels.addView(TextView(this).apply { text = title; textSize = 14f; setTypeface(null, Typeface.BOLD); setTextColor(getColor(R.color.cm_text)) })
            labels.addView(TextView(this).apply { text = subtitle; textSize = 11f; setTextColor(getColor(R.color.cm_muted)); setPadding(0, dp(3), 0, 0) })
            val toggle = android.widget.Switch(this).apply { isChecked = prefs.getBoolean(key, default); setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() } }
            row.addView(labels); row.addView(toggle); preferenceOptions.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        addInlineToggle("Download on Wi-Fi only", "Avoid using mobile data for downloads", "wifi_download_only", true)
        addGroupedDivider(preferenceOptions, dp(20))
        addInlineToggle("Push notifications", "Release alerts and app updates", "all_notifications", true)
        addGroupedDivider(preferenceOptions, dp(20))
        addInlineToggle("Autoplay next episode", "Continue to the next episode automatically", "autoplay_next", false)
        addGroupedDivider(preferenceOptions, dp(20))
        val cacheRow = addGroupedProfileRow(preferenceOptions, "Clear cache", cacheSizeLabel(), R.drawable.ic_info, false) {
            confirmBottom("Clear cache?", "Temporary cached files will be removed. Your watch list and preferences will stay.", "Clear cache") { clearAppCache() }
        } as LinearLayout
        (cacheRow.getChildAt(0) as? ImageView)?.visibility = View.GONE
        (cacheRow.getChildAt(1) as? LinearLayout)?.let { labels ->
            (labels.layoutParams as? LinearLayout.LayoutParams)?.let { it.marginStart = 0; labels.layoutParams = it }
        }
        cacheRow.addView(View(this).apply { setBackgroundColor(getColor(R.color.cm_border)) }, LinearLayout.LayoutParams(dp(1), dp(24)).apply { marginStart = dp(10); marginEnd = dp(12) })
        cacheRow.addView(TextView(this).apply { text = "Clear"; textSize = 12f; setTypeface(null, Typeface.BOLD); setTextColor(getColor(R.color.cm_accent)) })
        preferencesGroup.addView(preferenceOptions, LinearLayout.LayoutParams(-1, -2))

        addProfileSection(container, "CONTACTS & SUPPORT")
        val supportGroup = addProfileGroup(container)
        addGroupedProfileRow(supportGroup, "Telegram", "", R.drawable.ic_telegram, true) { openExternal("https://t.me/androidcus") }.let { (it as LinearLayout).getChildAt(0).let { icon -> (icon as ImageView).setColorFilter(android.graphics.Color.rgb(0, 136, 204)) } }
        addGroupedDivider(supportGroup)
        addGroupedProfileRow(supportGroup, "WhatsApp", "", R.drawable.ic_whatsapp, true) { openExternal("https://wa.me/+256708562567") }.let { (it as LinearLayout).getChildAt(0).let { icon -> (icon as ImageView).setColorFilter(android.graphics.Color.rgb(37, 211, 102)) } }

        addProfileSection(container, "APP INFORMATION")
        val appGroup = addProfileGroup(container)
        val versionName = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0.0" } catch (_: Exception) { "1.0.0" }
        addGroupedProfileRow(appGroup, "About Cinemax Play", "Version $versionName", R.drawable.ic_info) { showScreen("about") }
        addGroupedDivider(appGroup)
        addGroupedProfileRow(appGroup, "Terms & Conditions", "Review the terms of use", R.drawable.ic_terms) { showScreen("terms") }
        addGroupedDivider(appGroup)
        addGroupedProfileRow(appGroup, "Privacy Policy", "How app data is handled", R.drawable.ic_privacy) { showScreen("privacy") }
        addGroupedDivider(appGroup)
        addGroupedProfileRow(appGroup, "Share app", "Share Cinemax Play with friends", R.drawable.ic_share) {
            val shareIntent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "Check out Cinemax Play!") }
            startActivity(Intent.createChooser(shareIntent, "Share app"))
        }

        // Sign out is intentionally a standalone, centered, understated danger action.
        val signOut = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            addView(ImageView(this@MainActivity).apply { setImageResource(R.drawable.ic_logout); setColorFilter(android.graphics.Color.rgb(235, 65, 92)); layoutParams = LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginEnd = dp(8) } })
            addView(TextView(this@MainActivity).apply { text = "Sign out"; gravity = Gravity.CENTER; textSize = 13f; setTypeface(null, Typeface.BOLD); setTextColor(android.graphics.Color.rgb(235, 65, 92)) })
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(android.graphics.Color.rgb(25, 18, 22)); setStroke(dp(1), android.graphics.Color.rgb(48, 31, 37)); cornerRadius = dp(12).toFloat()
            }
            isClickable = true; isFocusable = true; setPadding(dp(16), dp(14), dp(16), dp(14))
            setOnClickListener { confirmBottom("Sign out?", "Are you sure you want to sign out of this device?", "Sign out") { prefs.edit().remove("profile_name").remove("profile_email").apply(); showScreen("home"); Toast.makeText(this@MainActivity, "Signed out", Toast.LENGTH_SHORT).show() } }
        }
        container.addView(signOut, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(24); bottomMargin = dp(12) })
    }

    private fun openExternal(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { Toast.makeText(this, "No app available to open this link", Toast.LENGTH_SHORT).show() }
    }

    private fun cacheSizeLabel(): String {
        fun sizeOf(file: java.io.File): Long = if (!file.exists()) 0L else if (file.isFile) file.length() else file.listFiles()?.sumOf { sizeOf(it) } ?: 0L
        return String.format(Locale.getDefault(), "%.1f MB", sizeOf(cacheDir) / (1024.0 * 1024.0))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun addProfileGroup(parent: LinearLayout): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = getDrawable(R.drawable.bg_surface_card)
            setPadding(0, dp(2), 0, dp(2))
            parent.addView(this, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(2) })
        }
    }

    private fun addGroupedDivider(parent: LinearLayout, startMargin: Int = dp(51)) {
        parent.addView(View(this).apply { setBackgroundColor(getColor(R.color.cm_border)) }, LinearLayout.LayoutParams(-1, dp(1)).apply {
            marginStart = startMargin; marginEnd = dp(14)
        })
    }

    private fun addGroupedProfileRow(parent: LinearLayout, title: String, subtitle: String, icon: Int, showChevron: Boolean = true, action: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14)); isClickable = true; isFocusable = true
        }
        val iconView = ImageView(this).apply { setImageResource(icon); setColorFilter(getColor(R.color.cm_accent)); layoutParams = LinearLayout.LayoutParams(dp(23), dp(23)) }
        val textBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(14) } }
        textBox.addView(TextView(this).apply { text = title; setTextColor(getColor(R.color.cm_text)); textSize = 14f; setTypeface(null, Typeface.BOLD) })
        if (subtitle.isNotBlank()) textBox.addView(TextView(this).apply { text = subtitle; setTextColor(getColor(R.color.cm_muted)); textSize = 11f; setPadding(0, dp(3), 0, 0) })
        row.addView(iconView); row.addView(textBox)
        if (showChevron) row.addView(ImageView(this).apply { setImageResource(R.drawable.ic_chevron_right); setColorFilter(getColor(R.color.cm_muted)); layoutParams = LinearLayout.LayoutParams(dp(14), dp(14)) })
        row.setOnClickListener { action() }
        parent.addView(row, LinearLayout.LayoutParams(-1, -2))
        return row
    }

    private fun addProfileSection(parent: LinearLayout, label: String) {
        parent.addView(TextView(this).apply { text = label; setTextColor(getColor(R.color.cm_muted)); textSize = 11f; setTypeface(null, Typeface.BOLD); setPadding(0, dp(22), 0, dp(9)) })
    }
    private fun addProfileRow(parent: LinearLayout, title: String, subtitle: String, icon: Int, action: () -> Unit): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = getDrawable(R.drawable.bg_surface_card); isClickable = true; isFocusable = true }
        val iconView = ImageView(this).apply { setImageResource(icon); setColorFilter(getColor(R.color.cm_accent)); layoutParams = LinearLayout.LayoutParams(dp(24), dp(24)) }
        val textBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(13) } }
        textBox.addView(TextView(this).apply { text = title; setTextColor(getColor(R.color.cm_text)); textSize = 14f; setTypeface(null, Typeface.BOLD) })
        if (subtitle.isNotBlank()) textBox.addView(TextView(this).apply { text = subtitle; setTextColor(getColor(R.color.cm_muted)); textSize = 11f; setPadding(0, dp(3), 0, 0) })
        row.addView(iconView); row.addView(textBox); row.addView(TextView(this).apply { text = "›"; textSize = 25f; setTextColor(getColor(R.color.cm_muted)) })
        row.setOnClickListener { action() }; parent.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) }); return row
    }

    private fun confirmBottom(title: String, message: String, actionText: String, action: () -> Unit) {
        val dialog = BottomSheetDialog(this)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(34), dp(24), dp(36))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(getColor(R.color.cm_surface))
                cornerRadii = floatArrayOf(dp(24).toFloat(), dp(24).toFloat(), dp(24).toFloat(), dp(24).toFloat(), 0f, 0f, 0f, 0f)
            }
        }
        panel.addView(TextView(this).apply { text = title; textSize = 20f; setTypeface(null, Typeface.BOLD); setTextColor(getColor(R.color.cm_text)) })
        panel.addView(TextView(this).apply { text = message; textSize = 14f; setTextColor(getColor(R.color.cm_muted)); setPadding(0, dp(14), 0, dp(30)) })
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        buttons.addView(MaterialButton(this).apply {
            text = "Cancel"; isAllCaps = false; cornerRadius = dp(12); setTextColor(getColor(R.color.cm_text))
            backgroundTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.cm_surface2))
            setOnClickListener { dialog.dismiss() }
        }, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginEnd = dp(10) })
        buttons.addView(MaterialButton(this).apply {
            text = actionText; isAllCaps = false; cornerRadius = dp(12); setTextColor(android.graphics.Color.WHITE)
            backgroundTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.cm_accent))
            setOnClickListener { dialog.dismiss(); action() }
        }, LinearLayout.LayoutParams(0, dp(54), 1f))
        panel.addView(buttons)

        dialog.setContentView(panel)
        dialog.setOnShowListener {
            dialog.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.apply {
                background = null
                backgroundTintList = null
            }
            dialog.findViewById<View>(com.google.android.material.R.id.touch_outside)
                ?.setBackgroundColor(android.graphics.Color.TRANSPARENT)
            dialog.window?.let { window ->
                window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                window.setDimAmount(0f)
                window.setBackgroundDrawableResource(android.R.color.transparent)
            }
        }
        dialog.show()
    }
    private fun clearAppCache() {
        try { cacheDir.listFiles()?.forEach { file -> file.deleteRecursively() } } catch (_: Exception) { }
        Toast.makeText(this, "Cache cleared", Toast.LENGTH_SHORT).show()
    }
    private fun showLegal(title: String, body: String) {
        showSimple(title, body, emptyList()) {}
        findViewById<TextView>(R.id.simpleSubtitle).textSize = 14f
        findViewById<TextView>(R.id.simpleSubtitle).setLineSpacing(dp(4).toFloat(), 1f)
        findViewById<TextView>(R.id.simpleEmpty).visibility = View.GONE
    }
    private fun showPreferences() {
        val root = layoutInflater.inflate(R.layout.view_simple, contentFrame, false); contentFrame.addView(root)
        root.findViewById<TextView>(R.id.simpleTitle).text = "Preferences"
        root.findViewById<TextView>(R.id.simpleSubtitle).text = "Customize your Cinemax Play experience."
        root.findViewById<View>(R.id.simpleBack).setOnClickListener { showScreen("profile") }
        root.findViewById<RecyclerView>(R.id.simpleRecycler).visibility = View.GONE
        root.findViewById<TextView>(R.id.simpleEmpty).visibility = View.GONE
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(20), 0, dp(12)) }
        fun addToggle(title: String, subtitle: String, key: String, default: Boolean) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(15), dp(15), dp(12), dp(15)); background = getDrawable(R.drawable.bg_surface_card) }
            val textCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
            textCol.addView(TextView(this).apply { text = title; textSize = 14f; setTypeface(null, Typeface.BOLD); setTextColor(getColor(R.color.cm_text)) })
            textCol.addView(TextView(this).apply { text = subtitle; textSize = 11f; setTextColor(getColor(R.color.cm_muted)); setPadding(0, dp(4), 0, 0) })
            val toggle = android.widget.Switch(this).apply { isChecked = prefs.getBoolean(key, default); setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() } }
            row.addView(textCol); row.addView(toggle); list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
        }
        addToggle("Download on Wi-Fi only", "Avoid using mobile data for downloads", "wifi_download_only", true)
        addToggle("All notifications", "Release alerts and app updates", "all_notifications", true)
        addToggle("Autoplay next episode", "Continue to the next episode automatically", "autoplay_next", false)
        (root as ViewGroup).addView(list, 2, LinearLayout.LayoutParams(-1, 0, 1f))
    }
    private fun showNotifications() {
        val root = layoutInflater.inflate(R.layout.view_simple, contentFrame, false); contentFrame.addView(root)
        root.findViewById<TextView>(R.id.simpleTitle).text = "Notifications"
        root.findViewById<TextView>(R.id.simpleSubtitle).text = "Manage release alerts and recommendations."
        root.findViewById<View>(R.id.simpleBack).setOnClickListener { showScreen("profile") }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(20), 0, 0) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(16), dp(12), dp(16)); background = getDrawable(R.drawable.bg_surface_card) }
        val label = TextView(this).apply { text = "All notifications\n\nRelease alerts and app updates"; textSize = 14f; setTextColor(getColor(R.color.cm_text)); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        val toggle = android.widget.Switch(this).apply { isChecked = prefs.getBoolean("all_notifications", true); setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("all_notifications", checked).apply() } }
        row.addView(label); row.addView(toggle); list.addView(row)
        root.findViewById<RecyclerView>(R.id.simpleRecycler).visibility = View.GONE; root.findViewById<TextView>(R.id.simpleEmpty).visibility = View.GONE
        (root as ViewGroup).addView(list, 2, LinearLayout.LayoutParams(-1, 0, 1f))
    }
    private fun showHistory() {
        val root = layoutInflater.inflate(R.layout.view_catalog, contentFrame, false); contentFrame.addView(root)
        root.findViewById<TextView>(R.id.catalogTitle).text = "Watch history"
        root.findViewById<View>(R.id.catalogBack).setOnClickListener { showScreen("profile") }
        root.findViewById<View>(R.id.catalogSearchBox).visibility = View.GONE
        root.findViewById<View>(R.id.catalogFilters).visibility = View.GONE
        val recentIds = prefs.getStringSet("history_ids", emptySet())?.toList().orEmpty()
        val items = (recentIds.mapNotNull { id -> Catalog.titles.firstOrNull { it.id == id } } + Catalog.titles.filter { it.id !in recentIds }).take(9)
        root.findViewById<TextView>(R.id.catalogCount).visibility = View.GONE
        root.findViewById<RecyclerView>(R.id.catalogRecycler).apply { layoutManager = GridLayoutManager(this@MainActivity, 3); adapter = MovieAdapter(items, true) { showDetail(it.id) } }
    }
    private fun showDownloads() {
        val root = layoutInflater.inflate(R.layout.view_simple, contentFrame, false)
        contentFrame.addView(root)
        root.findViewById<TextView>(R.id.simpleTitle).text = "Downloads"
        root.findViewById<TextView>(R.id.simpleSubtitle).visibility = View.GONE
        root.findViewById<View>(R.id.simpleBack).setOnClickListener { showScreen("profile") }
        root.findViewById<RecyclerView>(R.id.simpleRecycler).visibility = View.GONE
        root.findViewById<TextView>(R.id.simpleEmpty).visibility = View.GONE

        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(18), 0, dp(20))
        }
        val stat = android.os.StatFs(android.os.Environment.getDataDirectory().path)
        val totalBytes = stat.totalBytes.coerceAtLeast(1L)
        val freeBytes = stat.availableBytes.coerceAtLeast(0L)
        val usedBytes = (totalBytes - freeBytes).coerceAtLeast(0L)
        fun sizeLabel(bytes: Long): String = if (bytes >= 1024L * 1024L * 1024L) String.format(java.util.Locale.getDefault(), "%.1f GB", bytes / (1024.0 * 1024.0 * 1024.0)) else String.format(java.util.Locale.getDefault(), "%.0f MB", bytes / (1024.0 * 1024.0))

        val storageCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(11), dp(13), dp(11))
            background = getDrawable(R.drawable.bg_surface_card)
        }
        val storageHeading = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        storageHeading.addView(TextView(this).apply { text = "Device storage"; textSize = 14f; setTypeface(null, Typeface.BOLD); setTextColor(getColor(R.color.cm_text)); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        storageHeading.addView(TextView(this).apply { text = "${sizeLabel(freeBytes)} free"; textSize = 12f; setTextColor(getColor(R.color.cm_muted)) })
        storageCard.addView(storageHeading)
        storageCard.addView(TextView(this).apply { text = "${sizeLabel(usedBytes)} used of ${sizeLabel(totalBytes)}"; textSize = 11f; setTextColor(getColor(R.color.cm_muted)); setPadding(0, dp(5), 0, dp(8)) })
        storageCard.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = ((usedBytes * 100.0 / totalBytes).toInt()).coerceIn(0, 100)
            progressTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.cm_accent))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.cm_surface2))
            layoutParams = LinearLayout.LayoutParams(-1, dp(4))
        })
        list.addView(storageCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        val activeCount = downloadedIds.count { id -> (prefs.getString("download_state_$id", "Paused") ?: "Paused") != "Complete" }
        val completedCount = downloadedIds.count { id -> (prefs.getString("download_state_$id", "Paused") ?: "Paused") == "Complete" }
        val tabRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, 0)
        }
        val currentTab = prefs.getString("downloads_tab", "downloading") ?: "downloading"
        fun makeTab(label: String, key: String, count: Int): TextView = TextView(this).apply {
            text = "$label  $count"
            textSize = 13f
            gravity = Gravity.CENTER
            setTypeface(null, Typeface.BOLD)
            setPadding(dp(8), dp(13), dp(8), dp(13))
            setTextColor(getColor(if (currentTab == key) android.R.color.white else R.color.cm_muted))
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(getColor(if (currentTab == key) R.color.cm_accent else R.color.cm_bg))
            }
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            setOnClickListener { prefs.edit().putString("downloads_tab", key).apply(); showDownloads() }
        }
        tabRow.addView(makeTab("Downloading", "downloading", activeCount))
        tabRow.addView(makeTab("Completed", "completed", completedCount))
        list.addView(tabRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })

        val completedTab = currentTab == "completed"
        val items = Catalog.titles.filter { item ->
            downloadedIds.contains(item.id) && ((prefs.getString("download_state_${item.id}", "Paused") ?: "Paused") == "Complete") == completedTab
        }
        if (items.isEmpty()) {
            list.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(20), dp(34), dp(20), dp(34))
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(if (completedTab) R.drawable.ic_check else R.drawable.ic_download)
                    imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.cm_muted))
                    background = android.graphics.drawable.GradientDrawable().apply { shape = android.graphics.drawable.GradientDrawable.OVAL; setColor(getColor(R.color.cm_surface2)) }
                    setPadding(dp(14), dp(14), dp(14), dp(14))
                    layoutParams = LinearLayout.LayoutParams(dp(52), dp(52)).apply { bottomMargin = dp(14) }
                    contentDescription = if (completedTab) "No completed downloads" else "No active downloads"
                })
                addView(TextView(this@MainActivity).apply { text = if (completedTab) "No completed downloads yet" else "No active downloads"; textSize = 15f; setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER; setTextColor(getColor(R.color.cm_text)) })
                addView(TextView(this@MainActivity).apply { text = if (completedTab) "Completed downloads will appear here." else "Active or paused downloads will appear here."; textSize = 12f; gravity = Gravity.CENTER; setTextColor(getColor(R.color.cm_muted)); setPadding(0, dp(7), 0, 0) })
            })
        }
        items.forEach { item ->
            val state = prefs.getString("download_state_${item.id}", "Paused") ?: "Paused"
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(12), dp(12), dp(12))
                background = getDrawable(R.drawable.bg_surface_card)
            }
            val poster = ImageView(this).apply { layoutParams = LinearLayout.LayoutParams(dp(76), dp(104)); scaleType = ImageView.ScaleType.CENTER_CROP; contentDescription = item.title }
            RemoteImages.load(poster, item.image)
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) } }
            col.addView(TextView(this).apply { text = item.title; textSize = 14f; maxLines = 2; setTypeface(null, Typeface.BOLD); setTextColor(getColor(R.color.cm_text)) })
            col.addView(TextView(this).apply { text = if (completedTab) "Ready to watch · ${item.duration}" else "$state · ${item.duration}"; textSize = 11f; setTextColor(getColor(if (completedTab) R.color.cm_accent2 else R.color.cm_muted)); setPadding(0, dp(5), 0, dp(7)) })
            if (!completedTab) {
                col.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                    max = 100; progress = if (state == "Queued" || state == "Downloading") 35 else 0
                    progressTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.cm_accent))
                    progressBackgroundTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.cm_surface2))
                    layoutParams = LinearLayout.LayoutParams(-1, dp(4))
                })
            }
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(4), 0, 0) }
            fun action(label: String, fn: () -> Unit) {
                actions.addView(TextView(this@MainActivity).apply { text = label; textSize = 11f; setTypeface(null, Typeface.BOLD); setTextColor(getColor(R.color.cm_accent)); setPadding(0, dp(8), dp(14), dp(4)); isClickable = true; setOnClickListener { fn() } })
            }
            if (completedTab) {
                action("Play") { Toast.makeText(this, "No playable offline file is available for ${item.title} yet.", Toast.LENGTH_LONG).show() }
                action("Delete") { val ids = downloadedIds; ids.remove(item.id); prefs.edit().putStringSet("downloaded_ids", ids).remove("download_state_${item.id}").apply(); showDownloads() }
            } else {
                action(if (state == "Paused") "Resume" else "Pause") { prefs.edit().putString("download_state_${item.id}", if (state == "Paused") "Queued" else "Paused").apply(); showDownloads() }
                action("Cancel") { val ids = downloadedIds; ids.remove(item.id); prefs.edit().putStringSet("downloaded_ids", ids).remove("download_state_${item.id}").apply(); showDownloads() }
            }
            col.addView(actions)
            card.addView(poster); card.addView(col)
            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }
        (root as ViewGroup).addView(list, 2, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun showSimple(title: String, subtitle: String, items: List<NoticeItem>, onClick: (String) -> Unit) {
        val root = layoutInflater.inflate(R.layout.view_simple, contentFrame, false)
        contentFrame.addView(root)
        root.findViewById<TextView>(R.id.simpleTitle).text = title
        root.findViewById<TextView>(R.id.simpleSubtitle).text = subtitle
        root.findViewById<View>(R.id.simpleBack).setOnClickListener { showScreen("home") }
        val recycler = root.findViewById<RecyclerView>(R.id.simpleRecycler)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = NoticeAdapter(items, onClick)
        root.findViewById<TextView>(R.id.simpleEmpty).visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        if (items.isEmpty()) root.findViewById<TextView>(R.id.simpleEmpty).text = if (title == "Notifications") "You're all caught up" else "Nothing here yet"
    }

    private fun openPlayer(item: TitleItem) {
        startActivity(Intent(this, com.cinemax.player.PlayerActivity::class.java).apply {
            putExtra(com.cinemax.player.PlayerActivity.EXTRA_TITLE, item.title)
            putExtra(com.cinemax.player.PlayerActivity.EXTRA_TYPE, item.type)
            putExtra(com.cinemax.player.PlayerActivity.EXTRA_DURATION, item.duration)
            putExtra(com.cinemax.player.PlayerActivity.EXTRA_RETURN_DETAIL_ID, item.id)
        })
    }

    override fun onBackPressed() {
        if (currentScreen == "detail") showScreen(previousScreen)
        else if (currentScreen != "home") showScreen("home")
        else super.onBackPressed()
    }
}

private class MovieAdapter(
    private val items: List<TitleItem>, private val gridMode: Boolean, private val onClick: (TitleItem) -> Unit
) : RecyclerView.Adapter<MovieAdapter.Holder>() {
    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val poster: ImageView = view.findViewById(R.id.moviePoster)
        val rating: TextView = view.findViewById(R.id.movieRating)
        val title: TextView = view.findViewById(R.id.movieTitle)
        val meta: TextView = view.findViewById(R.id.movieMeta)
        val type: TextView = view.findViewById(R.id.movieType)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_movie, parent, false)
        if (gridMode) {
            // Cards fill their grid cell with equal 6dp side margins; the RecyclerView adds 10dp padding on both sides.
            val density = parent.resources.displayMetrics.density
            val screenDp = parent.resources.displayMetrics.widthPixels / density
            val cardDp = (screenDp - 20f) / 3f - 12f
            val lp = view.layoutParams as ViewGroup.MarginLayoutParams
            lp.width = ViewGroup.LayoutParams.MATCH_PARENT
            lp.marginStart = (6 * density).toInt()
            lp.marginEnd = (6 * density).toInt()
            view.layoutParams = lp
            val posterHeight = (cardDp * 1.38f * density).toInt()
            view.findViewById<View>(R.id.moviePosterFrame).layoutParams = view.findViewById<View>(R.id.moviePosterFrame).layoutParams.apply { height = posterHeight }
            view.findViewById<View>(R.id.moviePoster).layoutParams = view.findViewById<View>(R.id.moviePoster).layoutParams.apply { height = posterHeight }
        }
        return Holder(view)
    }
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]
        holder.title.text = item.title
        holder.meta.text = "${item.year} · ${item.genre}"
        holder.rating.text = String.format(Locale.US, "%.1f", item.rating)
        holder.rating.textSize = 8f
        holder.rating.setPadding(holder.itemView.resources.displayMetrics.density.let { (4 * it).toInt() }, 0, holder.itemView.resources.displayMetrics.density.let { (4 * it).toInt() }, 0)
        holder.rating.compoundDrawablePadding = 1
        holder.rating.compoundDrawablesRelative.filterNotNull().forEach { it.setBounds(0, 0, (9 * holder.itemView.resources.displayMetrics.density).toInt(), (9 * holder.itemView.resources.displayMetrics.density).toInt()) }
        holder.type.text = if (item.type == "series") "SERIES" else "MOVIE"
        RemoteImages.load(holder.poster, item.image, R.drawable.ic_cinemax_play_placeholder)
        holder.itemView.setOnClickListener { onClick(item) }
    }
    override fun getItemCount() = items.size
}

private class CastAdapter(private val items: List<CastMember>) : RecyclerView.Adapter<CastAdapter.Holder>() {
    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val image: ImageView = view.findViewById(R.id.castImage)
        val name: TextView = view.findViewById(R.id.castName)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_cast, parent, false))
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val cast = items[position]
        holder.name.text = cast.name
        RemoteImages.load(holder.image, cast.image, R.drawable.bg_poster)
    }
    override fun getItemCount() = items.size
}

private class NoticeAdapter(private val items: List<NoticeItem>, private val onClick: (String) -> Unit) : RecyclerView.Adapter<NoticeAdapter.Holder>() {
    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.simpleItemTitle)
        val message: TextView = view.findViewById(R.id.simpleItemMessage)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_simple, parent, false))
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]; holder.title.text = item.title; holder.message.text = item.message
        holder.itemView.setOnClickListener { onClick(item.title) }
    }
    override fun getItemCount() = items.size
}

private class EpisodeAdapter(
    private val items: List<EpisodeItem>, private val onPlay: (EpisodeItem) -> Unit, private val onDownload: (EpisodeItem) -> Unit
) : RecyclerView.Adapter<EpisodeAdapter.Holder>() {
    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val thumb: ImageView = view.findViewById(R.id.episodeThumb)
        val title: TextView = view.findViewById(R.id.episodeTitle)
        val desc: TextView = view.findViewById(R.id.episodeDesc)
        val duration: TextView = view.findViewById(R.id.episodeDuration)
        val play: View = view.findViewById(R.id.episodePlay)
        val download: View = view.findViewById(R.id.episodeDownload)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_episode, parent, false))
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val ep = items[position]
        holder.title.text = String.format(Locale.US, "%d.%02d  %s", ep.season, ep.number, ep.title)
        holder.desc.text = ep.description
        holder.duration.text = ep.duration
        RemoteImages.load(holder.thumb, ep.image, R.drawable.bg_poster)
        holder.itemView.setOnClickListener { onPlay(ep) }
        holder.play.setOnClickListener { onPlay(ep) }
        holder.download.setOnClickListener { onDownload(ep) }
    }
    override fun getItemCount() = items.size
}

