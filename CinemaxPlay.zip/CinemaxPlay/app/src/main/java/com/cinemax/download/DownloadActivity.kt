package com.cinemax.download

import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.cinemax.R
import java.util.Locale

class DownloadActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("cinemax_play_preferences", MODE_PRIVATE) }
    private val titles = listOf("horizon" to "The Last Horizon", "silent" to "Silent Echoes", "wild" to "Into the Wild", "deep" to "Deep Blue", "shadow" to "Shadow Protocol", "orbit" to "Beyond Orbit", "frozen" to "Frozen Kingdom", "after" to "After the Storm", "neon" to "Neon District", "north" to "Northbound", "orbitals" to "Orbital Station", "kingdom" to "The Hidden Kingdom", "coast" to "Coastline", "velocity" to "Velocity")
    private var completedTab = false
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_downloads)
        findViewById<View>(R.id.downloadBack).setOnClickListener { finish() }
        val stat = StatFs(Environment.getDataDirectory().path); val total = stat.totalBytes.coerceAtLeast(1L); val free = stat.availableBytes.coerceAtLeast(0L); val used = (total-free).coerceAtLeast(0L)
        fun size(b: Long) = if (b >= 1024L*1024*1024) String.format(Locale.getDefault(), "%.1f GB", b/(1024.0*1024*1024)) else String.format(Locale.getDefault(), "%.0f MB", b/(1024.0*1024))
        findViewById<TextView>(R.id.downloadFree).text = "${size(free)} free"
        findViewById<TextView>(R.id.downloadStorageSummary).text = "${size(used)} used of ${size(total)}"
        findViewById<ProgressBar>(R.id.downloadStorageProgress).progress = (used*100/total).toInt().coerceIn(0,100)
        findViewById<View>(R.id.tabDownloading).setOnClickListener { completedTab=false; render() }
        findViewById<View>(R.id.tabCompleted).setOnClickListener { completedTab=true; render() }
        render()
    }
    private fun render() {
        val ids = prefs.getStringSet("downloaded_ids", emptySet()) ?: emptySet()
        val list = findViewById<LinearLayout>(R.id.downloadItems); list.removeAllViews()
        val downloading = findViewById<TextView>(R.id.tabDownloading); val completed = findViewById<TextView>(R.id.tabCompleted)
        downloading.text = "Downloading  ${ids.count { (prefs.getString("download_state_$it", "Paused") ?: "Paused") != "Complete" }}"
        completed.text = "Completed  ${ids.count { (prefs.getString("download_state_$it", "Paused") ?: "Paused") == "Complete" }}"
        downloading.setTextColor(getColor(if (completedTab) R.color.cm_muted else R.color.cm_text)); completed.setTextColor(getColor(if (completedTab) R.color.cm_text else R.color.cm_muted))
        val items = ids.map { id -> id to (prefs.getString("download_title_$id", null) ?: titles.firstOrNull { it.first == id }?.second ?: id.replace("_", " ").replaceFirstChar { it.uppercase() }) }.filter { (id, _) -> ((prefs.getString("download_state_$id", "Paused") ?: "Paused") == "Complete") == completedTab }
        if (items.isEmpty()) {
            val empty = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(dp(20),dp(48),dp(20),dp(48)) }
            empty.addView(TextView(this).apply { text=if(completedTab) "✓" else "↓"; textSize=32f; gravity=Gravity.CENTER; setTextColor(getColor(R.color.cm_accent2)) }, LinearLayout.LayoutParams(-1,dp(52)))
            empty.addView(TextView(this).apply { text=if(completedTab) "No completed downloads yet" else "No active downloads"; textSize=16f; setTypeface(null,Typeface.BOLD); gravity=Gravity.CENTER; setTextColor(getColor(R.color.cm_text)) })
            empty.addView(TextView(this).apply { text=if(completedTab) "Completed downloads will appear here." else "Movies you queue will appear here."; textSize=12f; gravity=Gravity.CENTER; setTextColor(getColor(R.color.cm_muted)); setPadding(0,dp(8),0,0) })
            list.addView(empty); return
        }
        items.forEach { (id,title) ->
            val state = prefs.getString("download_state_$id", "Paused") ?: "Paused"
            val card = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(15),dp(14),dp(15),dp(12)); background=getDrawable(R.drawable.bg_surface_card) }
            card.addView(TextView(this).apply { text=title; textSize=15f; setTypeface(null,Typeface.BOLD); setTextColor(getColor(R.color.cm_text)) })
            card.addView(TextView(this).apply { text=if(completedTab) "Ready to watch" else state; textSize=12f; setTextColor(getColor(if(completedTab) R.color.cm_accent2 else R.color.cm_muted)); setPadding(0,dp(5),0,dp(8)) })
            if (!completedTab) card.addView(ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply { max=100; progress=if(state=="Queued"||state=="Downloading") 35 else 0; progressTintList=android.content.res.ColorStateList.valueOf(getColor(R.color.cm_accent)); layoutParams=LinearLayout.LayoutParams(-1,dp(4)) })
            val actions = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.END }
            fun action(label:String, fn:()->Unit) { actions.addView(TextView(this@DownloadActivity).apply { text=label; textSize=12f; setTypeface(null,Typeface.BOLD); setTextColor(getColor(R.color.cm_accent2)); setPadding(dp(12),dp(12),0,dp(3)); setOnClickListener { fn() } }) }
            if (completedTab) action("Play") { Toast.makeText(this,"No offline video file is connected for $title yet.",Toast.LENGTH_SHORT).show() } else action(if(state=="Paused") "Resume" else "Pause") { prefs.edit().putString("download_state_$id",if(state=="Paused") "Queued" else "Paused").apply(); render() }
            action(if(completedTab) "Delete" else "Cancel") { val updated=ids.toMutableSet(); updated.remove(id); prefs.edit().putStringSet("downloaded_ids",updated).remove("download_state_$id").apply(); render() }
            card.addView(actions); list.addView(card,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(10) })
        }
    }
}
