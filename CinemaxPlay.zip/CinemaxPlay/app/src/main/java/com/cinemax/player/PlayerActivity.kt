package com.cinemax.player

import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.cinemax.R

class PlayerActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_TITLE = "player_title"
        const val EXTRA_TYPE = "player_type"
        const val EXTRA_DURATION = "player_duration"
        const val EXTRA_RETURN_DETAIL_ID = "return_detail_id"
    }
    private var speedIndex = 0
    private val speeds = listOf("1.0x", "1.25x", "1.5x", "1.75x", "2.0x")
    private var locked = false
    private val prefs by lazy { getSharedPreferences("cinemax_play_preferences", MODE_PRIVATE) }
    private var isSeries = false
    private var mediaDurationSeconds = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.navigationBarColor = Color.BLACK
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        setContentView(R.layout.activity_player)

        val title = intent.getStringExtra(EXTRA_TITLE) ?: "Cinemax Play"
        val type = intent.getStringExtra(EXTRA_TYPE) ?: "movie"
        val time = intent.getStringExtra(EXTRA_DURATION) ?: "00:00"
        isSeries = type == "series"
        mediaDurationSeconds = parseDuration(time)
        findViewById<TextView>(R.id.playerTitle).text = title
        findViewById<TextView>(R.id.playerSubtitle).text = if (isSeries) "Cinemax Series" else "Cinemax Original"

        // All icons now come from the layout XML (real vector drawables), nothing to set here.
        refreshMyListIcon(title)

        findViewById<View>(R.id.playerBack).setOnClickListener { finish() }
        findViewById<View>(R.id.playerPlay).setOnClickListener { toast("Add a playable video URL to enable streaming") }
        findViewById<View>(R.id.playerBack10).setOnClickListener { toast("Rewind needs a connected video source") }
        findViewById<View>(R.id.playerForward10).setOnClickListener { toast("Forward needs a connected video source") }
        findViewById<TextView>(R.id.playerSpeed).setOnClickListener {
            speedIndex = (speedIndex + 1) % speeds.size
            (it as TextView).text = speeds[speedIndex]
            toast("Playback speed ${speeds[speedIndex]} selected")
        }
        findViewById<View>(R.id.playerLock).setOnClickListener { toggleLock() }
        findViewById<View>(R.id.playerSettings).setOnClickListener { showSettings() }
        findViewById<SeekBar>(R.id.playerSeek).setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser && mediaDurationSeconds > 0) findViewById<TextView>(R.id.playerCurrentTime).text = formatTime(mediaDurationSeconds * progress / 1000)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) { toast("Seeking takes effect when a video source is connected") }
        })
        findViewById<View>(R.id.playerEpisodes).setOnClickListener { showEpisodes() }
        findViewById<View>(R.id.playerMyList).setOnClickListener { toggleMyList(title) }
        findViewById<View>(R.id.playerDownload).setOnClickListener { queueDownload(title) }
        findViewById<View>(R.id.playerNext).setOnClickListener { showNextEpisode() }
        findViewById<View>(R.id.playerUnlockOverlay).setOnClickListener { if (locked) toggleLock() }
    }

    private fun parseDuration(value: String): Int = value.split(":").mapNotNull { it.toIntOrNull() }.let { parts -> when (parts.size) { 3 -> parts[0] * 3600 + parts[1] * 60 + parts[2]; 2 -> parts[0] * 60 + parts[1]; 1 -> parts[0]; else -> 0 } }
    private fun formatTime(seconds: Int): String = if (seconds >= 3600) String.format("%02d:%02d:%02d", seconds / 3600, (seconds % 3600) / 60, seconds % 60) else String.format("%02d:%02d", seconds / 60, seconds % 60)

    private fun toggleLock() {
        locked = !locked
        val controlsVisibility = if (locked) View.GONE else View.VISIBLE
        // Controls (and their dark shades) hide; the video underneath keeps playing.
        listOf(R.id.playerHeader, R.id.playerFooter, R.id.playerCenter, R.id.playerTopShade, R.id.playerBottomShade)
            .forEach { findViewById<View>(it).visibility = controlsVisibility }
        findViewById<View>(R.id.playerUnlockOverlay).visibility = if (locked) View.VISIBLE else View.GONE
    }

    private fun showSettings() {
        val options = arrayOf("Playback speed", "Video quality", "Subtitles", "Audio track")
        AlertDialog.Builder(this).setTitle("Playback settings").setItems(options) { _, which ->
            when (which) {
                0 -> findViewById<TextView>(R.id.playerSpeed).performClick()
                1 -> toast("Video quality selection needs a streaming source")
                2 -> toast("Subtitle tracks are not supplied for this title")
                3 -> toast("Audio tracks are not supplied for this title")
            }
        }.show()
    }

    private fun showEpisodes() {
        if (!isSeries) { toast("Episodes are available for series only"); return }
        val episodes = arrayOf("Episode 1 · Playable source not set", "Episode 2 · Playable source not set", "Episode 3 · Playable source not set")
        AlertDialog.Builder(this).setTitle("Episodes").setItems(episodes) { _, which -> toast("Episode ${which + 1} selected; connect its video URL to play") }.setNegativeButton("Close", null).show()
    }

    private fun showNextEpisode() {
        if (!isSeries) { toast("Next episode is available for series only"); return }
        AlertDialog.Builder(this).setTitle("Next episode").setMessage("The next episode can be selected, but its playable video URL has not been configured.").setPositiveButton("OK", null).show()
    }

    private fun refreshMyListIcon(title: String) {
        val saved = prefs.getStringSet("player_my_list_titles", emptySet())?.contains(title) == true
        val tv = findViewById<TextView>(R.id.playerMyList)
        tv.text = if (saved) "Added" else "My List"
        tv.setCompoundDrawablesWithIntrinsicBounds(if (saved) R.drawable.ic_player_check else R.drawable.ic_player_add, 0, 0, 0)
    }

    private fun toggleMyList(title: String) {
        val key = "player_my_list_titles"
        val set = prefs.getStringSet(key, emptySet())?.toMutableSet() ?: mutableSetOf()
        val added = if (set.contains(title)) { set.remove(title); false } else { set.add(title); true }
        prefs.edit().putStringSet(key, set).apply()
        refreshMyListIcon(title)
        toast(if (added) "Added to My List" else "Removed from My List")
    }

    private fun queueDownload(title: String) {
        val id = intent.getStringExtra(EXTRA_RETURN_DETAIL_ID) ?: title.lowercase().replace(Regex("[^a-z0-9]+"), "_")
        val ids = prefs.getStringSet("downloaded_ids", emptySet())?.toMutableSet() ?: mutableSetOf()
        ids.add(id)
        prefs.edit().putStringSet("downloaded_ids", ids).putString("download_state_$id", "Queued").putString("download_title_$id", title).apply()
        toast("$title added to downloads")
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    @Suppress("DEPRECATION") override fun onBackPressed() { finish() }
}
